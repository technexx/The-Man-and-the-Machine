package com.example.onlyme;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

public class Game extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_activity);

        FragmentManager fragmentManager = getSupportFragmentManager();

        StoryFragment storyFragment = new StoryFragment();
        StatsFragment statsFragment = new StatsFragment();

        fragmentManager.beginTransaction()
                .add(R.id.story_text, storyFragment)
                .add(R.id.game_stats, statsFragment)
                .commit();

    }
}
