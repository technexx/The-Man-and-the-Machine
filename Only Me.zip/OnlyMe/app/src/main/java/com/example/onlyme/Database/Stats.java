package com.example.onlyme.Database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "Stats")


public class Stats {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private int senses;
    private int intuition;
    private int intelligence;
    private int empathy;
    private int extroversion;

    private int population;
    private int morale;
    private int freedom;
    private int superstition;

    private int favors;
    private int percept;

    public Stats() {
    }


    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public int getSenses() {
        return senses;
    }
    public void setSenses(int senses) {
        this.senses = senses;
    }
    public int getIntuition() {
        return intuition;
    }
    public void setIntuition (int intuition) {
        this.intuition = intuition;
    }
    public int getIntelligence () {
        return intelligence;
    }
    public void setIntelligence(int intelligence) {
        this.intelligence = intelligence;
    }
    public int getEmpathy() {
        return empathy;
    }
    public void setEmpathy (int empathy) {
        this.empathy = empathy;
    }

    public int getExtroversion () {
        return extroversion;
    }
    public void setExtroversion (int extroversion) {
        this.extroversion = extroversion;
    }

    public int getPopulation() {
        return population;
    }
    public void setPopulation(int population) {
        this.population = population;
    }

    public int getMorale() {
        return morale;
    }
    public void setMorale (int morale) {
        this.morale = morale;
    }

    public int getFreedom() {
        return freedom;
    }
    public void setFreedom(int freedom) {
        this.freedom = freedom;
    }
    public int getSuperstition() {
        return superstition;
    }
    public void setSuperstition(int superstition) {
        this.superstition = superstition;
    }
    public int getFavors () {
        return favors;
    }
    public void setFavors (int favors) {
        this.favors = favors;
    }
    public int getPercept() {
        return percept;
    }
    public void setPercept(int percept) {
        this.percept = percept;
    }

}