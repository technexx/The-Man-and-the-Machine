package com.example.onlyme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button startButton = findViewById(R.id.start_game);
        final Button continueButton = findViewById(R.id.continue_game);
        Button previousGames = findViewById(R.id.previous_games);
        Button credits = findViewById(R.id.credits);

        final Button activeConfirm = findViewById(R.id.active_confirm);
        final TextView activeGame = findViewById(R.id.active_game);

        startButton.setText(R.string.start);
        activeConfirm.setText(R.string.confirm);

        startButton.setVisibility(View.VISIBLE);
        activeGame.setVisibility(View.INVISIBLE);

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Game.class);
                startActivity(intent);
            }
        });
    }
}
