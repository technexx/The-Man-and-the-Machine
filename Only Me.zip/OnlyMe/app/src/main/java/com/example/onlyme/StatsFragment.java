package com.example.onlyme;

import androidx.fragment.app.Fragment;

public class StatsFragment extends Fragment {
}
