package com.example.onlyme;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class ResultsFragment extends Fragment {

    private View root;

    public View onCreateView(final LayoutInflater inflater, final ViewGroup container, final Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.results_fragment, container, false);

        final Button nextDay = root.findViewById(R.id.next_day);
        final TextView result = root.findViewById(R.id.result);

        final TextView power = root.findViewById(R.id.power);
        final TextView benevolence = root.findViewById(R.id.benevolence);
        final TextView temperament = root.findViewById(R.id.temperament);
        final TextView devotion = root.findViewById(R.id.devotion);
        final TextView popularity = root.findViewById(R.id.popularity);

        final TextView powerResult = root.findViewById(R.id.resultOne);
        final TextView benevolenceResult = root.findViewById(R.id.resultTwo);
        final TextView temperamentResult = root.findViewById(R.id.resultThree);
        final TextView devotionResult = root.findViewById(R.id.resultFour);
        final TextView popularityResult = root.findViewById(R.id.resultFive);

        nextDay.setText(R.string.continue_game);
        power.setText(R.string.power);
        benevolence.setText(R.string.benevolence);
        temperament.setText(R.string.temperament);
        devotion.setText(R.string.devotion);
        popularity.setText(R.string.popularity);

        //TextView stats are only String Arrays - no need to store in Database.

        return root;

    }
}
