package com.example.onlyme.Database;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.AsyncTask;

public class StatsRepository {

    private StatsDatabase statsDatabase;
    private Stats stats;
    private StatsDao statsDao;

    public StatsRepository(Context context) {
        statsDatabase = StatsDatabase.getDatabase(context);
        statsDao = statsDatabase.statsDao();
        stats = statsDao.loadAllStats();
    }

    public void populateStats() {
        Stats stats = new Stats();
        stats.setSenses(100); stats.setIntuition(100); stats.setIntelligence(100); stats.setEmpathy(100); stats.setExtroversion(100);
        stats.setPopulation(100); stats.setMorale(100); stats.setFreedom(100); stats.setSuperstition(100);
        stats.setFavors(10); stats.setPercept(5);
        insertStats(stats);
    }

    public void resetStats() {
        //Do not create a new Stats object here, it will not update anything when called.
        stats.setSenses(100); stats.setIntuition(100); stats.setIntelligence(100); stats.setEmpathy(100); stats.setExtroversion(100);
        stats.setPopulation(100); stats.setMorale(100); stats.setFreedom(100); stats.setSuperstition(100);
        stats.setFavors(10); stats.setPercept(5);
        updateStats(stats);
    }

    public int loadSenses() {
        return statsDao.loadSenses();
    }
    public int loadIntuition() {
        return statsDao.loadIntuition();
    }
    public int loadIntelligence() {
        return statsDao.loadIntelligence();
    }
    public int loadEmpathy() {
        return statsDao.loadEmpathy();
    }
    public int loadExtroversion() {
        return statsDao.loadExtroversion();
    }
    public int loadPopulation() {
        return statsDao.loadPopulation();
    }

    public int loadMorale() {
        return statsDao.loadMorale();
    }
    public int loadFreedom() {
        return statsDao.loadFreedom();
    }
    public int loadSuperstition() {
        return statsDao.loadSuperstition();
    }
    public int loadFavors() {
        return statsDao.loadFavors();
    }
    public int loadPercept() {
        return statsDao.loadPercept();
    }

    @SuppressLint("StaticFieldLeak")
    public void insertStats(final Stats stats){
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                statsDatabase.statsDao().insert(stats);
                return null;
            }
        }
                .execute();
    }

    @SuppressLint("StaticFieldLeak")
    public void updateStats(final Stats stats){
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                statsDatabase.statsDao().update(stats);
                return null;
            }
        }
                .execute();
    }

    @SuppressLint("StaticFieldLeak")
    public void deleteStats(final Stats stats){
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                statsDatabase.statsDao().delete(stats);
                return null;
            }
        }
                .execute();
    }

}
