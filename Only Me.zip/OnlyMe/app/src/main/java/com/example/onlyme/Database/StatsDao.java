package com.example.onlyme.Database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

@Dao

public interface StatsDao {

    @Query("SELECT * from STATS WHERE id =:statId")
    int getStat(int statId);

    @Query("SELECT * from STATS")
    Stats loadAllStats();

    @Query("SELECT senses from STATS")
    int loadSenses();

    @Query("SELECT intuition from STATS")
    int loadIntuition();

    @Query("SELECT intelligence from STATS")
    int loadIntelligence();

    @Query("SELECT empathy from STATS")
    int loadEmpathy();

    @Query("SELECT extroversion from STATS")
    int loadExtroversion();

    @Query("SELECT population from STATS")
    int loadPopulation();

    @Query("SELECT morale from STATS")
    int loadMorale();

    @Query("SELECT freedom from STATS")
    int loadFreedom();

    @Query("SELECT superstition from STATS")
    int loadSuperstition();

    @Query("SELECT favors from STATS")
    int loadFavors();

    @Query("SELECT percept from STATS")
    int loadPercept();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(Stats stats);

    @Update
    void update(Stats stats);

    @Delete
    void delete(Stats stats);

    @Query("DELETE FROM Stats")
    void deleteAll();


}
