package com.example.onlyme.Database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = { Stats.class }, version = 1, exportSchema = false)

public abstract class StatsDatabase extends RoomDatabase {

    private static StatsDatabase INSTANCE;

    public abstract StatsDao statsDao();

    public static StatsDatabase getDatabase(Context context) {
        if (INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                    StatsDatabase.class, "stats_db")
                    .allowMainThreadQueries()
                    .build();
        }
        return INSTANCE;
    }

    public static void destroyInstance() {
        INSTANCE = null;
    }
}